st7789
* @file Adafruit_st7789.h
*
* This is the documentation for Adafruit's st7789 driver for the
* Arduino platform.
*
* These displays use SPI to communicate, 4 or 5 pins are required
* to interface (RST is optional).
*
* Adafruit invests time and resources providing this open source code,
* please support Adafruit and open-source hardware by purchasing
* products from Adafruit!
*
*
* This library depends on <a href="https://github.com/adafruit/Adafruit_GFX">
* Adafruit_GFX</a> being present on your system. Please make sure you have
* installed the latest version before using this library.
*
* Written by Limor "ladyada" Fried for Adafruit Industries.
*
* BSD license, all text here must be included in any redistribution.
*
*/

#ifndef _ADAFRUIT_st7789H_
#define _ADAFRUIT_st7789H_

#include "Arduino.h"
#include "Print.h"
#include <SPI.h>
#include "Adafruit_GFX.h"
#include <Adafruit_SPITFT.h>
#include <Adafruit_SPITFT_Macros.h>

#define st7789_TFTWIDTH   160      ///< st7789 max TFT width
#define st7789_TFTHEIGHT  128      ///< st7789 max TFT height

#define st7789_NOP        0x00     ///< No-op register
#define st7789_SWRESET    0x01     ///< Software reset register
#define st7789_RDDID      0x04     ///< Read display identification information
#define st7789_RDDST      0x09     ///< Read Display Status

#define st7789_SLPIN      0x10     ///< Enter Sleep Mode
#define st7789_SLPOUT     0x11     ///< Sleep Out
#define st7789_PTLON      0x12     ///< Partial Mode ON
#define st7789_NORON      0x13     ///< Normal Display Mode ON

#define st7789_RDMODE     0x0A     ///< Read Display Power Mode
#define st7789_RDMADCTL   0x0B     ///< Read Display MADCTL
#define st7789_RDPIXFMT   0x0C     ///< Read Display Pixel Format
#define st7789_RDIMGFMT   0x0D     ///< Read Display Image Format
#define st7789_RDSELFDIAG 0x0F     ///< Read Display Self-Diagnostic Result

#define st7789_INVOFF     0x20     ///< Display Inversion OFF
#define st7789_INVON      0x21     ///< Display Inversion ON
#define st7789_GAMMASET   0x26     ///< Gamma Set
#define st7789_DISPOFF    0x28     ///< Display OFF
#define st7789_DISPON     0x29     ///< Display ON

#define st7789_CASET      0x2A     ///< Column Address Set
#define st7789_PASET      0x2B     ///< Page Address Set
#define st7789_RAMWR      0x2C     ///< Memory Write
#define st7789_RAMRD      0x2E     ///< Memory Read

#define st7789_PTLAR      0x30     ///< Partial Area
#define st7789_VSCRDEF    0x33     ///< Vertical Scrolling Definition
#define st7789_MADCTL     0x36     ///< Memory Access Control
#define st7789_VSCRSADD   0x37     ///< Vertical Scrolling Start Address
#define st7789_PIXFMT     0x3A     ///< COLMOD: Pixel Format Set

#define st7789_FRMCTR1    0xB1     ///< Frame Rate Control (In Normal Mode/Full Colors)
#define st7789_FRMCTR2    0xB2     ///< Frame Rate Control (In Idle Mode/8 colors)
#define st7789_FRMCTR3    0xB3     ///< Frame Rate control (In Partial Mode/Full Colors)
#define st7789_INVCTR     0xB4     ///< Display Inversion Control
#define st7789_DFUNCTR    0xB6     ///< Display Function Control

#define st7789_PWCTR1     0xC0     ///< Power Control 1
#define st7789_PWCTR2     0xC1     ///< Power Control 2
#define st7789_PWCTR3     0xC2     ///< Power Control 3
#define st7789_PWCTR4     0xC3     ///< Power Control 4
#define st7789_PWCTR5     0xC4     ///< Power Control 5
#define st7789_VMCTR1     0xC5     ///< VCOM Control 1
#define st7789_VMCTR2     0xC7     ///< VCOM Control 2

#define st7789_RDID1      0xDA     ///< Read ID 1
#define st7789_RDID2      0xDB     ///< Read ID 2
#define st7789_RDID3      0xDC     ///< Read ID 3
#define st7789_RDID4      0xDD     ///< Read ID 4

#define st7789_GMCTRP1    0xE0     ///< Positive Gamma Correction
#define st7789_GMCTRN1    0xE1     ///< Negative Gamma Correction
//#define st7789_PWCTR6     0xFC

// Color definitions
#define st7789_BLACK       0x0000  ///<   0,   0,   0
#define st7789_NAVY        0x000F  ///<   0,   0, 123
#define st7789_DARKGREEN   0x03E0  ///<   0, 125,   0
#define st7789_DARKCYAN    0x03EF  ///<   0, 125, 123
#define st7789_MAROON      0x7800  ///< 123,   0,   0
#define st7789_PURPLE      0x780F  ///< 123,   0, 123
#define st7789_OLIVE       0x7BE0  ///< 123, 125,   0
#define st7789_LIGHTGREY   0xC618  ///< 198, 195, 198
#define st7789_DARKGREY    0x7BEF  ///< 123, 125, 123
#define st7789_BLUE        0x001F  ///<   0,   0, 255
#define st7789_GREEN       0x07E0  ///<   0, 255,   0
#define st7789_CYAN        0x07FF  ///<   0, 255, 255
#define st7789_RED         0xF800  ///< 255,   0,   0
#define st7789_MAGENTA     0xF81F  ///< 255,   0, 255
#define st7789_YELLOW      0xFFE0  ///< 255, 255,   0
#define st7789_WHITE       0xFFFF  ///< 255, 255, 255
#define st7789_ORANGE      0xFD20  ///< 255, 165,   0
#define st7789_GREENYELLOW 0xAFE5  ///< 173, 255,  41
#define st7789_PINK        0xFC18  ///< 255, 130, 198

/**************************************************************************/
st7789
@brief Class to manage hardware interface with st7789 chipset (also seems to work with ILI9340)
*/
/**************************************************************************/

class Adafruit_st7789 : public Adafruit_SPITFT {
    public:
        Adafruit_st7789(int8_t _CS, int8_t _DC, int8_t _MOSI, int8_t _SCLK,
          int8_t _RST = -1, int8_t _MISO = -1);
        Adafruit_st7789(int8_t _CS, int8_t _DC, int8_t _RST = -1);
#if !defined(ESP8266)
        Adafruit_st7789(SPIClass *spiClass, int8_t dc,
          int8_t cs = -1, int8_t rst = -1);
#endif // end !ESP8266
        Adafruit_st7789(tftBusWidth busWidth, int8_t d0, int8_t wr, int8_t dc,
          int8_t cs = -1, int8_t rst = -1, int8_t rd = -1);

        void    begin(uint32_t freq=0);
        void    setRotation(uint8_t r);
        void    invertDisplay(bool i);
        void    scrollTo(uint16_t y);
        void    setScrollMargins(uint16_t top, uint16_t bottom);

        // Transaction API not used by GFX
        void    setAddrWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h);

        uint8_t readcommand8(uint8_t reg, uint8_t index=0);
};

#endif // _ADAFRUIT_st7789H_
